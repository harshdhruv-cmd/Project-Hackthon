import React, { useState, useEffect } from 'react';
import { Mic, Circle, Power } from 'lucide-react';

function App() {
  const [isActive, setIsActive] = useState(false);
  const [message, setMessage] = useState('Systems ready...');
  const [pulseSize, setPulseSize] = useState(0);

  useEffect(() => {
    if (isActive) {
      const messages = [
        'Initializing systems...',
        'Running diagnostics...',
        'All systems operational.',
        'How may I assist you today?'
      ];
      
      messages.forEach((msg, index) => {
        setTimeout(() => setMessage(msg), index * 1000);
      });
    } else {
      setMessage('Systems ready...');
    }
  }, [isActive]);

  useEffect(() => {
    const interval = setInterval(() => {
      setPulseSize(prev => (prev + 1) % 100);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-black text-blue-400 flex items-center justify-center p-4">
      <div className="relative w-full max-w-2xl aspect-video bg-gray-900/50 rounded-lg backdrop-blur-sm border border-blue-500/20 shadow-2xl overflow-hidden">
        {/* Background Effect */}
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072')] bg-cover bg-center opacity-10" />
        
        {/* Main Content */}
        <div className="relative h-full flex flex-col items-center justify-center p-8">
          {/* Central Circle */}
          <div className="relative mb-8">
            <Circle 
              className={`w-32 h-32 stroke-1 ${isActive ? 'text-blue-500' : 'text-gray-600'}`}
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <Power
                className={`w-12 h-12 cursor-pointer transition-colors duration-300 ${
                  isActive ? 'text-blue-400' : 'text-gray-600'
                }`}
                onClick={() => setIsActive(!isActive)}
              />
            </div>
            {isActive && (
              <>
                <div 
                  className="absolute inset-0 border-2 border-blue-400/20 rounded-full"
                  style={{
                    transform: `scale(${1 + pulseSize * 0.01})`,
                    opacity: 1 - pulseSize * 0.01
                  }}
                />
                <div className="absolute inset-0 animate-spin-slow">
                  <div className="h-full w-full rounded-full border-t-2 border-blue-400/20" />
                </div>
              </>
            )}
          </div>

          {/* Message Display */}
          <div className="h-16 flex items-center justify-center">
            <p className="text-xl font-light tracking-wider">{message}</p>
          </div>

          {/* Voice Input Indicator */}
          {isActive && (
            <div className="mt-8 flex items-center gap-4">
              <Mic className="w-6 h-6 text-blue-400" />
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <div
                    key={i}
                    className="w-1 bg-blue-400"
                    style={{
                      height: `${Math.random() * 20 + 10}px`,
                      animation: 'pulse 1s infinite',
                      animationDelay: `${i * 0.1}s`
                    }}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;